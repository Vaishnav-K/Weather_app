export class WeatherItem{
    constructor(public cityName: string,public discription: string,public temprature: number){}
}