import {WeatherItem} from "./weather";
export const WEATHER_ITEMS: WeatherItem[]=[
    new WeatherItem('Lahore','Rainy',32),
    new WeatherItem('Islamabad','Rainy',32)
];
